﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace HalloTPL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello TPL!");
            Console.WriteLine();

            // Sequentiell
            //Zähle();
            //Zähle();
            //Zähle();


            // Parallel
            //Console.WriteLine("Neu:");
            //Parallel.Invoke(Zähle, Zähle, Zähle, () => Console.WriteLine("Hallali!") );
            //Console.WriteLine("Neu:");
            //Parallel.Invoke(Zähle, Zähle, Zähle, () => Console.WriteLine("Hallali!"));
            //Console.WriteLine("Neu:");
            //Parallel.Invoke(Zähle, Zähle, Zähle, () => Console.WriteLine("Hallali!"));

            // Parallel 2
            //Parallel.For(0, 100000, i =>
            //    {
            //        Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId}: {i}");
            //    }
            //);

            //Task

            Task task1 = new Task(() =>
           {
               Console.WriteLine("T1 gestartet");
               Thread.Sleep(800);
               throw new InvalidCastException();
               Console.WriteLine("T1 fertig");
           } );


            // Hier immer rein
            task1.ContinueWith(t =>
            {
                Console.WriteLine("Task1 continue (immer)");
            } );

            // Hier nur bei erfolgreicher Ausführung des Threads rein
            task1.ContinueWith( t =>
            {
                Console.WriteLine("Task1 Alles prima, kommt zum Ende!");
            },  CancellationToken.None,
                TaskContinuationOptions.OnlyOnRanToCompletion,
                TaskScheduler.Default);

            // Hier nur bei Fehler (Exception) innerhahlb des Threads rein
            task1.ContinueWith(t =>
           {
               Console.WriteLine($"Task1 ERROR: {t.Exception.Message}");
           },   CancellationToken.None, 
                TaskContinuationOptions.OnlyOnFaulted, 
                TaskScheduler.Default );

            Task<long> task2 = new Task<long>( () =>
            {
                Console.WriteLine("T2 gestartet");
                Thread.Sleep(800);
                Console.WriteLine("T2 fertig");
                return 45231;
            });

            task1.Start();
            task2.Start();

            //Console.WriteLine(task2.Result);

            //Task.WaitAny(task1, task2);

            // Ende errechit
            Console.WriteLine();
            Console.WriteLine("This is the END!");
            Console.ReadLine();
        }

        private static void Zähle()
        {
            for (int i = 0; i < 10; i++)
            {
                //Console.WriteLine($"{i}");
                Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId}: {i}");
            }
        }
    }
}
