﻿using System;

namespace HalloWCF.Host
{
    public class Wurst
    {
        public int length { get; set; }

        public string MeatType { get; set; }

        public DateTime BestBefore { get; set; }

        public int EndCount { get; set; } = 2;
    }
}
