﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HalloWCF.Host
{
     public class Service1 : IService1
    {
        public string GetData(int value)
        {
            //return string.Format("You entered: {0}", value);
            return $"You enterd: {value}";

        }

        public IEnumerable<Wurst> GetWurst()
        {
            yield return new Wurst() { length = 7, BestBefore = DateTime.Now.AddDays(5), MeatType = "Cat" };
            yield return new Wurst() { length = 4, BestBefore = DateTime.Now.AddDays(15), MeatType = "Dog" };
            yield return new Wurst() { length = 3, BestBefore = DateTime.Now.AddDays(8), MeatType = "Snail" };
            yield return new Wurst() { length = 14, BestBefore = DateTime.Now.AddDays(12), MeatType = "Elephant", EndCount = 3 };
        }
    }
}
