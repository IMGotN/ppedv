﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HalloAsync
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartOhneThread(object sender, RoutedEventArgs e)
        {
            progressBar1.Value = 0;

            for (int i = 0; i <= 100; i++)
            {
                progressBar1.Value = i;
                Thread.Sleep(10);
            }
        }

        private void StartTask(object sender, RoutedEventArgs e)
        {
            ((Button)sender).IsEnabled = false;
            progressBar1.Value = 0;

            Task.Run(() =>
           {
               for (int i = 0; i <= 100; i++)
               {
                    //progressBar1.Value = i; // => System.InvalidOperationException: 'Der aufrufende Thread kann nicht auf dieses Objekt zugreifen, da sich das Objekt im Besitz eines anderen Threads befindet.'
                    progressBar1.Dispatcher.Invoke(() => progressBar1.Value = i);
                   Thread.Sleep(20);
               }

               progressBar1.Dispatcher.Invoke(() => ((Button)sender).IsEnabled = true);
           });
        }

        private void StartTaskWithTS(object sender, RoutedEventArgs e)
        {
            cts = new CancellationTokenSource();

            ((Button)sender).IsEnabled = false;
            progressBar1.Value = 0;
            var taskScheduler = TaskScheduler.FromCurrentSynchronizationContext();

            Task.Run(() =>
            {
                for (int i = 0; i <= 100; i++)
                {
                    Task.Factory.StartNew( () =>
                        progressBar2.Value = i, 
                        cts.Token, 
                        TaskCreationOptions.None, 
                        taskScheduler
                     );
                    Thread.Sleep(20);
                    if(cts.IsCancellationRequested )
                    {
                        break;
                    }
                }
            }).ContinueWith(t => ((Button)sender).IsEnabled = true, CancellationToken.None, TaskContinuationOptions.None, taskScheduler);
        }

        CancellationTokenSource cts = null;
        private void CancelTaskWithTS(object sender, RoutedEventArgs e)
        {
            if(cts != null)
            {
                cts.Cancel();
            }
        }

        private async void ReadHttp(object sender, RoutedEventArgs e)
        {
            var webClient = new WebClient();
            tb1.Text = await webClient.DownloadStringTaskAsync("http://b2-software.de");
        }

        private async void OldMethod(object sender, RoutedEventArgs e)
        {
            long zahl = await LameOldMethodAsync();

            MessageBox.Show(zahl.ToString());
        }

        private Task<long> LameOldMethodAsync()
        {
            return Task.Run( () => LameOldMethod() );
        }

        private long LameOldMethod ()
        {
            Thread.Sleep(3000);
            return 123498756;
        }
    }
}
