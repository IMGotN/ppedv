﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HalloREST_Cats
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void loadJson(object sender, RoutedEventArgs e)
        {
            // using-Block
            using (var wc = new WebClient())
            {
                wc.Encoding = Encoding.UTF8;
                string json = await wc.DownloadStringTaskAsync("http://cat-fact.herokuapp.com/facts");
                jsonTb.Text = json;

                CatFactResult result = JsonConvert.DeserializeObject<CatFactResult>(json);
                myGrid.ItemsSource = result.all.Where( x => x.text.Length>5 ).OrderBy( x => x.upvotes.Length);

            } // wc.Dispose()
        }
    }
}
